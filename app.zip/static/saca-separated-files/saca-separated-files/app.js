// app.js: behavior & logic
(function(){
  const PREF_KEY='sacaPrefs';
  const qs = s=>document.querySelector(s);
  const STR = window.STR;

  const prefs = (()=>{ try{ return JSON.parse(localStorage.getItem(PREF_KEY)||'{}'); }catch{ return {}; } })();
  function savePrefs(){ localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); }

  const langSelect = qs('#langSelect');
  const themeSelect = qs('#themeSelect');
  const contrastToggle = qs('#contrastToggle');
  const easyToggle = qs('#easyToggle');

  function applyTheme(){ document.documentElement.setAttribute('data-theme', prefs.theme || 'auto'); }
  function applyContrast(){ document.documentElement.setAttribute('data-contrast', prefs.contrast==='high' ? 'high' : 'normal'); }
  function applyEasy(){ document.body.classList.toggle('easy-read', !!prefs.easy); }

  function t(path){
    const parts = path.split('.');
    let cur = STR[prefs.lang || 'en'] || STR.en;
    for(const p of parts){ if(cur && p in cur) cur = cur[p]; else return null; }
    return cur;
  }
  function applyStrings(){
    document.querySelectorAll('[data-i18n]').forEach(el=>{
      const key = el.getAttribute('data-i18n'); const val = t(key); if(val!=null) el.textContent = val;
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{
      const key = el.getAttribute('data-i18n-placeholder'); const val = t(key); if(val!=null) el.setAttribute('placeholder', val);
    });
  }

  function processNLP(text){ return (text||'').trim().replace(/\s+/g,' ').toLowerCase(); }
  const RULES = {
    categories: [
      {key:'breathing',terms:['trouble breathing','shortness of breath','wheeze','asthma','can’t breathe','cant breathe','breathless']},
      {key:'chest',terms:['chest pain','tight chest','pressure chest']},
      {key:'belly',terms:['stomach pain','abdominal pain','vomit','diarrhoea','diarrhea','nausea','belly ache']},
      {key:'skin',terms:['rash','hives','itchy','skin','swelling lips','swelling tongue']},
      {key:'fever',terms:['fever','temperature','high temp','chills']},
      {key:'injury',terms:['injury','bleeding','fracture','head injury','burn','cut','wound']}
    ],
    severe:['severe','unconscious','not breathing','stopped breathing','blue lips','heavy bleeding','spurting blood','chest pain','shortness of breath','can’t breathe','cant breathe','numbness','weakness one side','stroke','anaphylaxis','allergic reaction','seizure','fitting'],
    moderate:['moderate','worsening','high fever','persistent','vomiting','dehydration','pain 7/10','blood in','wheeze','asthma flare']
  };
  function assessSeverity(text){
    const tt = processNLP(text||'');
    const dict = STR[prefs.lang || 'en'];
    if(!tt) return {level:'none', category:null, advice:dict.triage.start};
    let cat=null; for(const c of RULES.categories){ if(c.terms.some(term=>tt.includes(term))){ cat=c.key; break; } }
    const sev = RULES.severe.some(x=>tt.includes(x)) ? 'severe' : RULES.moderate.some(x=>tt.includes(x)) ? 'moderate' : 'mild';
    let advice = dict.triage.start;
    if(sev==='mild') advice = "Rest, hydrate, and monitor. If symptoms persist or worsen, see your GP.";
    if(sev==='moderate') advice = "Same-day GP / urgent care is recommended. Monitor closely.";
    if(sev==='severe') advice = "Emergency signs detected. Call 000 now or go to the nearest emergency department.";
    return {level:sev, category:cat, advice};
  }
  function updateTriage({rawEl,nlpEl,badgeEl,catEl,advEl,ctaEl}){
    const res = assessSeverity((rawEl?.value||nlpEl?.value||''));
    badgeEl.className = 'badge ' + (res.level==='severe'?'b-sev':res.level==='moderate'?'b-mod':'b-mild');
    const cap = res.level==='none'?'—':res.level[0].toUpperCase()+res.level.slice(1);
    badgeEl.textContent = cap;
    const catMap = STR[prefs.lang||'en'].cat;
    catEl.textContent = "Category: " + (res.category ? catMap[res.category] : '—');
    advEl.textContent = res.advice;
    ctaEl.style.display = res.level==='severe' ? 'flex' : 'none';
  }

  function connectBoxes(rawEl,nlpEl,refs){
    if(!rawEl || !nlpEl) return;
    const upd = ()=>{ nlpEl.value = processNLP(rawEl.value); if(refs) updateTriage({rawEl,nlpEl,...refs}); };
    rawEl.addEventListener('input', upd); upd();
  }

  const rawHome = qs('#rawHome'), nlpHome = qs('#nlpHome');
  const rawChoose = qs('#rawChoose'), nlpChoose = qs('#nlpChoose');
  const triHome = {badgeEl:qs('#sevBadgeHome'),catEl:qs('#catHome'),advEl:qs('#advHome'),ctaEl:qs('#ctaHome')};
  const triChoose = {badgeEl:qs('#sevBadgeChoose'),catEl:qs('#catChoose'),advEl:qs('#advChoose'),ctaEl:qs('#ctaChoose')};
  connectBoxes(rawHome,nlpHome,triHome); connectBoxes(rawChoose,nlpChoose,triChoose);

  const searchInput = qs('#symptomSearch');
  if(searchInput && rawChoose){
    const sync=()=>{ rawChoose.value = searchInput.value; rawChoose.dispatchEvent(new Event('input')); };
    searchInput.addEventListener('input', sync);
  }
  function addSymptomToInputs(sym){
    const arr = (searchInput?.value||'').split(',').map(s=>s.trim()).filter(Boolean);
    if(!arr.includes(sym)) arr.push(sym);
    const joined = arr.join(', ');
    if(searchInput){ searchInput.value = joined; searchInput.dispatchEvent(new Event('input')); }
    if(rawChoose){ rawChoose.value = joined; rawChoose.dispatchEvent(new Event('input')); }
  }
  document.querySelectorAll('.add-symptom').forEach(b=>b.addEventListener('click',e=>{
    const sym = e.currentTarget.getAttribute('data-symptom'); if(sym) addSymptomToInputs(sym);
  }));

  // History
  const LS_KEY='sacaHistory';
  const readHist=()=>{ try{return JSON.parse(localStorage.getItem(LS_KEY)||'[]')}catch{return[]} };
  const writeHist=a=>localStorage.setItem(LS_KEY,JSON.stringify(a));
  function addHistory(raw,nlp){ if(!raw && !nlp) return; const a=readHist(); a.unshift({ts:Date.now(),raw:(raw||'').trim(),nlp:(nlp||'').trim()}); writeHist(a); renderHistory(); }
  function clearHistory(){ writeHist([]); renderHistory(); }
  function seedHistory(){ const seed=[{ts:Date.now()-86400000*2,raw:"chest pain with sweating",nlp:processNLP("chest pain with sweating")},{ts:Date.now()-86400000*4,raw:"fever since last night, headache",nlp:processNLP("fever since last night, headache")},{ts:Date.now()-86400000*7,raw:"itchy rash on back",nlp:processNLP("itchy rash on back")}]; writeHist([...seed,...readHist()]); renderHistory(); }
  function fmt(dt){ return new Date(dt).toLocaleString(); }
  function renderHistory(){
    const tbody = document.querySelector('#histTable tbody'); const empty=qs('#histEmpty'); if(!tbody) return;
    const rows=readHist(); tbody.innerHTML=''; if(!rows.length){ if(empty) empty.style.display='block'; qs('#histTable').style.display='none'; return; }
    if(empty) empty.style.display='none'; qs('#histTable').style.display='table';
    rows.forEach(r=>{ const tr=document.createElement('tr'); tr.innerHTML=`<td>${fmt(r.ts)}</td><td class="mono">${r.raw||''}</td><td class="mono">${r.nlp||''}</td>`; tbody.appendChild(tr); });
  }
  qs('#saveFromHome')?.addEventListener('click',()=>{ addHistory(rawHome?.value||'', nlpHome?.value||''); location.hash='#history'; });
  qs('#saveFromChoose')?.addEventListener('click',()=>{ addHistory(rawChoose?.value||'', nlpChoose?.value||''); location.hash='#history'; });
  qs('#clearHistory')?.addEventListener('click',()=>{ if(confirm('Clear all saved entries on this device?')) clearHistory(); });
  qs('#seedHistory')?.addEventListener('click',seedHistory);
  window.addEventListener('load',renderHistory);
  window.addEventListener('hashchange',()=>{ if(location.hash==='#history') renderHistory(); });

  // Mic
  (function(){
    const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
    const micHomeBtn=qs('#micHome'), micChooseBtn=qs('#micChoose');
    const micHomeLabel=qs('#micHomeLabel'), micChooseLabel=qs('#micChooseLabel');
    const dict = STR[prefs.lang || 'en'];
    if(!SpeechRecognition){
      [micHomeBtn,micChooseBtn].forEach(b=>{ if(b){ b.disabled=false; b.title="Speech not supported"; }});
      if(micHomeLabel) micHomeLabel.textContent = dict.home.type || "Speech not supported";
      if(micChooseLabel) micChooseLabel.textContent = dict.home.type || "Speech not supported";
      return;
    }
    const makeRec=(onResult,onEnd)=>{ const r=new SpeechRecognition(); r.lang=(prefs.lang==='es'?'es-ES':'en-AU'); r.interimResults=true; r.maxAlternatives=1;
      r.onresult=e=>{ let s=''; for(let i=0;i<e.results.length;i++){ s+=e.results[i][0].transcript; } onResult(s.trim()); };
      r.onerror=()=>onEnd(false); r.onend=()=>onEnd(true); return r; };
    const wire=(btn,label,write)=>{ if(!btn) return; let rec=null,listening=false;
      const start=()=>{ if(listening) return; listening=true; label&&(label.textContent=(dict.home.mic||'Tap here to speak')+'…'); rec=makeRec(txt=>write(txt),()=>{listening=false; label&&(label.textContent=dict.home.mic||'Tap here to speak');}); try{rec.start();}catch{} };
      const stop=()=>{ if(rec){try{rec.stop();}catch{}} listening=false; label&&(label.textContent=dict.home.mic||'Tap here to speak'); };
      btn.addEventListener('click',()=>listening?stop():start());
    };
    wire(micHomeBtn,micHomeLabel,(txt)=>{ rawHome.value=txt; rawHome.dispatchEvent(new Event('input')); });
    wire(micChooseBtn,micChooseLabel,(txt)=>{ if(searchInput) searchInput.value=txt; rawChoose.value=txt; rawChoose.dispatchEvent(new Event('input')); });
  })();

  // Auth demo
  qs('#doLogin')?.addEventListener('click',()=>{
    const email=qs('#loginEmail').value.trim(), pass=qs('#loginPass').value.trim();
    if(!email||!pass){ alert('Enter email and password.'); return; }
    qs('#loginOk').style.display='inline'; setTimeout(()=>{ location.hash='#home'; qs('#loginOk').style.display='none'; }, 900);
  });

  // Chatbot
  const CHAT_KEY='sacaChat';
  const readChat=()=>{ try{return JSON.parse(localStorage.getItem(CHAT_KEY)||'[]')}catch{return[]} };
  const writeChat=a=>localStorage.setItem(CHAT_KEY,JSON.stringify(a));
  function ts(){ return new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); }
  const chatBody=qs('#chatBody'), chatInput=qs('#chatInput'), chatSend=qs('#chatSend');
  function renderChat(){ if(!chatBody) return; chatBody.innerHTML=''; readChat().forEach(m=>{ const d=document.createElement('div'); d.className='bubble '+(m.role==='user'?'me':'bot'); d.innerHTML=`${m.text}<span class="stamp">${m.time}</span>`; chatBody.appendChild(d); }); chatBody.scrollTop=chatBody.scrollHeight; }
  function pushMessage(role,text){ const arr=readChat(); arr.push({role,text,time:ts()}); writeChat(arr); renderChat(); }
  function botReplyTo(text){
    const res=assessSeverity(text), catMap=STR[prefs.lang||'en'].cat;
    const catLabel = res.category ? catMap[res.category] : '—';
    const sev = res.level==='none'?'Unknown':res.level[0].toUpperCase()+res.level.slice(1);
    let reply = `Category: ${catLabel}\nSeverity: ${sev}\nAdvice: ${res.advice}`;
    if(res.level==='severe'){ reply += `\n\n▶ ${STR[prefs.lang||'en'].triage.call000} · tel:000`; }
    pushMessage('bot', reply);
  }
  function sendChat(txt){ const t=(txt??chatInput.value).trim(); if(!t) return; pushMessage('user',t); chatInput.value=''; setTimeout(()=>botReplyTo(t), 250); }
  chatSend?.addEventListener('click',()=>sendChat());
  chatInput?.addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); sendChat(); }});
  document.querySelectorAll('.chip-btn').forEach(b=>b.addEventListener('click',()=>sendChat(b.getAttribute('data-chip')||'')));
  window.addEventListener('load',()=>{
    if(readChat().length===0){ writeChat([{role:'bot',text:'Hi, I’m SACA. Tell me your symptoms. For emergencies, call 000.',time:ts()}]); }
    renderChat();
  });

  // Prefs init & listeners
  function initPrefsUI(){
    langSelect.value = prefs.lang || 'en';
    themeSelect.value = prefs.theme || 'auto';
    contrastToggle.checked = prefs.contrast === 'high';
    easyToggle.checked = !!prefs.easy;
    applyTheme(); applyContrast(); applyEasy(); applyStrings();
  }
  langSelect.addEventListener('change',()=>{ prefs.lang = langSelect.value; savePrefs(); applyStrings(); });
  themeSelect.addEventListener('change',()=>{ prefs.theme = themeSelect.value; savePrefs(); applyTheme(); });
  contrastToggle.addEventListener('change',()=>{ prefs.contrast = contrastToggle.checked ? 'high' : 'normal'; savePrefs(); applyContrast(); });
  easyToggle.addEventListener('change',()=>{ prefs.easy = !!easyToggle.checked; savePrefs(); applyEasy(); });
  window.addEventListener('load', initPrefsUI);
})();