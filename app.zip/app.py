import streamlit as st
import tempfile
import os
import pandas as pd
from pipeline.pipeline import VoiceToTextPipeline
from saca_predictor import load_models, predict_from_text

st.set_page_config(page_title="SACA Voice + Text Predictor", layout="centered")
st.title("SACA — Voice & Text Intake (Aboriginal English friendly)")

st.header("1️⃣ How are you feeling today?")
col1, col2 = st.columns(2)
with col1:
    text_input = st.text_area("Type your answer:", height=120)
with col2:
    audio_file = st.file_uploader("Or upload audio:", type=["wav", "mp3", "m4a"])

st.header("2️⃣ How long have you been feeling this?")
duration = st.selectbox("Select:", ("A few hours", "A day", "2–3 days", "A week or more"))

st.header("How bad is the issue?")
severity = st.selectbox("Select:", ("Light", "Medium", "Severe"))

st.header("3️⃣ Have you noticed any other symptoms?")
symptoms = st.multiselect("Select any:", [
    "Fever", "Nausea or vomiting", "Cough or breathing difficulty", "Diarrhea",
    "Chest pain or tightness", "Dizziness or fatigue", "None of these"
])

st.header("4️⃣ Does it get better or worse after any of these?")
when_change = st.selectbox("Select:", [
    "After eating", "When resting", "When moving or standing", "Changes randomly", "Not sure"
])

if st.button("Process"):
    pipeline = VoiceToTextPipeline()
    raw, norm = "", ""
    if audio_file is not None:
        suffix = os.path.splitext(audio_file.name)[1]
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(audio_file.read())
            tmp_path = tmp.name
        st.audio(tmp_path)
        st.info("Transcribing audio...")
        raw, norm = pipeline.process(tmp_path)
        os.remove(tmp_path)
    elif text_input.strip():
        raw, norm = pipeline.process_text(text_input.strip())
    else:
        st.error("Please provide input.")
        st.stop()

    st.subheader("Raw transcription / input")
    st.success(raw)
    st.subheader("Normalized text")
    st.info(norm)

    models = load_models("models")
    output = predict_from_text(norm or raw, models)

    st.subheader("Prediction")
    st.write(output)

    result_text = f"Raw:\n{raw}\n\nNormalized:\n{norm}\n\nOutput:\n{output}"
    st.download_button("Download result", data=result_text, file_name="saca_result.txt")
